import { useState } from 'react';
import Navbar from './components/Navbar';
import Homepage from './components/Homepage';
import AboutMe from './components/AboutMe';
import Projects from './components/Projects';
import AcademicPlanner from './components/AcademicPlanner';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderActivePage = () => {
    switch (activeTab) {
      case 'home':
        return <Homepage setActiveTab={setActiveTab} />;
      case 'about':
        return <AboutMe />;
      case 'projects':
        return <Projects />;
      case 'planner':
        return <AcademicPlanner />;
      case 'contact':
        return <Contact />;
      default:
        return <Homepage setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col justify-between" id="app-root">
      <div className="space-y-6">
        {/* Navigation Bar */}
        <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Main Content Area */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div 
            className="transition-all duration-300 ease-in-out"
            id="page-content-wrapper"
          >
            {renderActivePage()}
          </div>
        </main>
      </div>

      {/* Footer Area */}
      <Footer />
    </div>
  );
}
