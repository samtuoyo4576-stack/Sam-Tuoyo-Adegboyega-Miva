import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-400 mt-20 border-t border-slate-900" id="portal-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        
        {/* Copyright section */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-light text-slate-500" id="footer-copyright-panel">
          <p className="text-center sm:text-left">
            © Copyright 2025 MIVA Open University All Rights Reserved
          </p>
          <div className="flex gap-4">
            <span className="hover:text-slate-300 transition-colors font-mono text-xxs cursor-pointer">TERMS OF USE</span>
            <span className="hover:text-slate-300 transition-colors font-mono text-xxs cursor-pointer">PRIVACY POLICY</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
