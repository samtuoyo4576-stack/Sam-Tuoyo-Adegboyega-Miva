import React, { useState, useEffect } from 'react';
import { INITIAL_TASKS } from '../data';
import { Plus, Trash, CheckCircle, Circle, Calendar, AlertCircle, Sparkles, Filter, Check } from 'lucide-react';

export default function AcademicPlanner() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [course, setCourse] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [notes, setNotes] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  
  // Validation state
  const [formError, setFormError] = useState('');

  // Load from local storage or defaults on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('academic_tasks');
      if (saved) {
        setTasks(JSON.parse(saved));
      } else {
        setTasks(INITIAL_TASKS);
      }
    } catch (e) {
      console.warn('localStorage is not accessible, using in-memory state.', e);
      setTasks(INITIAL_TASKS);
    }
  }, []);

  // Save to local storage whenever tasks change
  const saveTasks = (updatedTasks) => {
    setTasks(updatedTasks);
    try {
      localStorage.setItem('academic_tasks', JSON.stringify(updatedTasks));
    } catch (e) {
      console.warn('localStorage is not accessible, state not persisted.', e);
    }
  };

  // Add Task Handler
  const handleAddTask = (e) => {
    e.preventDefault();
    setFormError('');

    // JS validation: Ensure no empty title or course
    if (!title.trim()) {
      setFormError('Task title is required.');
      return;
    }
    if (!course.trim()) {
      setFormError('Course / Subject is required.');
      return;
    }
    if (!dueDate) {
      setFormError('Please select a valid target due date.');
      return;
    }

    const newTask = {
      id: `task-${Date.now()}`,
      title: title.trim(),
      course: course.trim(),
      dueDate,
      priority,
      completed: false,
      notes: notes.trim() || undefined
    };

    const updated = [newTask, ...tasks];
    saveTasks(updated);

    // Reset Form Fields
    setTitle('');
    setCourse('');
    setDueDate('');
    setPriority('Medium');
    setNotes('');
  };

  // Toggle completed status
  const toggleTask = (id) => {
    const updated = tasks.map(task => {
      if (task.id === id) {
        return { ...task, completed: !task.completed };
      }
      return task;
    });
    saveTasks(updated);
  };

  // Delete task
  const deleteTask = (id) => {
    const updated = tasks.filter(task => task.id !== id);
    saveTasks(updated);
  };

  // Stats calculation
  const totalTasksCount = tasks.length;
  const completedTasksCount = tasks.filter(t => t.completed).length;
  const activeTasksCount = totalTasksCount - completedTasksCount;
  const completionPercentage = totalTasksCount > 0 ? Math.round((completedTasksCount / totalTasksCount) * 100) : 0;

  // Filter implementation
  const filteredTasks = tasks.filter(task => {
    if (statusFilter === 'Active') return !task.completed;
    if (statusFilter === 'Completed') return task.completed;
    return true;
  });

  return (
    <div className="space-y-12" id="planner-container">
      {/* Page Header */}
      <section className="text-center max-w-3xl mx-auto space-y-4" id="planner-header">
        <h2 className="font-display font-black text-3xl sm:text-4xl text-slate-900 tracking-tight">
          Academic Study Planner
        </h2>
        <p className="text-slate-500 text-sm sm:text-base leading-relaxed">
          Maintain full control over your assignments, study targets, and exams. Add new academic items, manage status levels, and monitor cumulative progress.
        </p>
      </section>

      {/* Task Statistics Cards Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="planner-stats">
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-slate-400 font-mono text-xxs uppercase tracking-wider font-semibold">Total Load</span>
            <p className="font-display text-2xl font-bold text-slate-800">{totalTasksCount} Assignments</p>
          </div>
          <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-bold">∑</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-slate-400 font-mono text-xxs uppercase tracking-wider font-semibold">Completed</span>
            <p className="font-display text-2xl font-bold text-emerald-600">{completedTasksCount} Tasks</p>
          </div>
          <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">✓</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-slate-400 font-mono text-xxs uppercase tracking-wider font-semibold">Active / Pending</span>
            <p className="font-display text-2xl font-bold text-amber-600">{activeTasksCount} Tasks</p>
          </div>
          <div className="w-10 h-10 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">!</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-slate-400 font-mono text-xxs uppercase tracking-wider font-semibold">Completion rate</span>
            <span className="font-mono text-xs font-bold text-blue-600">{completionPercentage}%</span>
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-600 rounded-full transition-all duration-500" 
              style={{ width: `${completionPercentage}%` }}
            ></div>
          </div>
        </div>
      </section>

      {/* Main Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="planner-grid-layout">
        
        {/* Form to Add Tasks (5 Columns) */}
        <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6" id="add-task-form-card">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
              <Plus className="w-5.5 h-5.5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900">Add Academic Task</h3>
              <p className="text-slate-400 text-xs font-mono">RECORD ASSIGNMENT</p>
            </div>
          </div>

          <form onSubmit={handleAddTask} className="space-y-4" id="academic-task-form">
            {formError && (
              <div className="flex items-start gap-2 bg-rose-50 text-rose-700 px-4 py-3 rounded-xl text-xs border border-rose-100" id="form-error-display">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <div className="space-y-1.5">
              <label htmlFor="task-title" className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                Task Title *
              </label>
              <input
                type="text"
                id="task-title"
                placeholder="e.g. Prepare presentation slides"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all focus:outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="task-course" className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                Course / Subject Code *
              </label>
              <input
                type="text"
                id="task-course"
                placeholder="e.g. CSC201 - Data Structures"
                value={course}
                onChange={(e) => setCourse(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label htmlFor="task-due-date" className="text-xs font-bold text-slate-600 uppercase tracking-wider animate-pulse-once">
                  Due Date *
                </label>
                <input
                  type="date"
                  id="task-due-date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl px-3 py-3 text-sm transition-all focus:outline-none cursor-pointer"
                />
              </div>

              <div className="space-y-1.5">
                <label htmlFor="task-priority" className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Priority Level
                </label>
                <select
                  id="task-priority"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl px-3 py-3 text-sm transition-all focus:outline-none cursor-pointer"
                >
                  <option value="Low">Low Priority</option>
                  <option value="Medium">Medium Priority</option>
                  <option value="High">High Priority</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="task-notes" className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                Additional Notes
              </label>
              <textarea
                id="task-notes"
                placeholder="Optional study reference details, links, or instructions..."
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all focus:outline-none resize-none"
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-semibold py-3 rounded-xl shadow-lg shadow-blue-600/10 transition-all text-sm flex items-center justify-center gap-2 cursor-pointer"
              id="add-task-submit-btn"
            >
              <Plus className="w-4 h-4" />
              <span>Record New Task</span>
            </button>
          </form>
        </div>

        {/* Task Viewer List with HTML Table (7 Columns) */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm flex flex-col gap-6" id="tasks-table-card">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600">
                <Calendar className="w-5.5 h-5.5" />
              </div>
              <div>
                <h3 className="font-display font-bold text-lg text-slate-900">Task Register</h3>
                <p className="text-slate-400 text-xs font-mono">DURABLE LOCAL REGISTER</p>
              </div>
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1 bg-slate-50 p-1.5 rounded-xl border border-slate-200/50 self-start" id="tasks-status-filters">
              {['All', 'Active', 'Completed'].map((tab) => (
                <button
                  key={tab}
                  id={`status-filter-${tab.toLowerCase()}`}
                  onClick={() => setStatusFilter(tab)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    statusFilter === tab
                      ? 'bg-white text-slate-800 shadow-sm font-semibold'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Table Container */}
          <div className="overflow-x-auto" id="tasks-table-wrapper">
            {filteredTasks.length === 0 ? (
              <div className="py-12 text-center space-y-2.5" id="no-tasks-placeholder">
                <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 mx-auto">✓</div>
                <h4 className="font-display font-bold text-sm text-slate-800">No Tasks Found</h4>
                <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
                  Everything caught up! Either select a different filter or register a new academic study goal in the builder panel.
                </p>
              </div>
            ) : (
              <table className="w-full border-collapse text-left" id="academic-tasks-table">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-mono text-xxs uppercase tracking-wider font-bold">
                    <th className="py-3 px-4 w-10">Status</th>
                    <th className="py-3 px-4">Task Information</th>
                    <th className="py-3 px-4">Subject</th>
                    <th className="py-3 px-4 text-center">Priority</th>
                    <th className="py-3 px-4 text-right">Deadline</th>
                    <th className="py-3 px-4 text-center w-12">Delete</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredTasks.map((task) => {
                    const priorityStyles = {
                      High: 'bg-rose-50 text-rose-700 border-rose-100/60',
                      Medium: 'bg-amber-50 text-amber-700 border-amber-100/60',
                      Low: 'bg-emerald-50 text-emerald-700 border-emerald-100/60'
                    };

                    return (
                      <tr 
                        key={task.id} 
                        id={`task-row-${task.id}`}
                        className={`hover:bg-slate-50/50 transition-colors group ${
                          task.completed ? 'opacity-65' : ''
                        }`}
                      >
                        {/* Completed Status Checkbox */}
                        <td className="py-4 px-4 text-center">
                          <button
                            onClick={() => toggleTask(task.id)}
                            id={`task-toggle-${task.id}`}
                            className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-all cursor-pointer ${
                              task.completed 
                                ? 'bg-emerald-500 border-emerald-500 text-white' 
                                : 'border-slate-300 hover:border-blue-500 text-transparent hover:text-slate-400'
                            }`}
                            aria-label={task.completed ? "Mark as active" : "Mark as completed"}
                          >
                            <Check className="w-4 h-4 stroke-[3]" />
                          </button>
                        </td>

                        {/* Title and Notes */}
                        <td className="py-4 px-4 min-w-48">
                          <div className="space-y-0.5">
                            <span className={`text-sm font-semibold block transition-all ${
                              task.completed ? 'line-through text-slate-400' : 'text-slate-800'
                            }`}>
                              {task.title}
                            </span>
                            {task.notes && (
                              <p className="text-slate-400 text-xxs font-normal leading-relaxed line-clamp-1 max-w-xs group-hover:line-clamp-none transition-all">
                                {task.notes}
                              </p>
                            )}
                          </div>
                        </td>

                        {/* Course ID */}
                        <td className="py-4 px-4 whitespace-nowrap">
                          <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-md">
                            {task.course}
                          </span>
                        </td>

                        {/* Priority level */}
                        <td className="py-4 px-4 text-center">
                          <span className={`inline-block text-xxs font-bold px-2 py-0.5 rounded-full border ${priorityStyles[task.priority]}`}>
                            {task.priority}
                          </span>
                        </td>

                        {/* Due Date */}
                        <td className="py-4 px-4 text-right whitespace-nowrap text-slate-500 text-xs font-mono font-medium">
                          {task.dueDate}
                        </td>

                        {/* Delete Action Button */}
                        <td className="py-4 px-4 text-center">
                          <button
                            onClick={() => deleteTask(task.id)}
                            id={`task-delete-btn-${task.id}`}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            aria-label="Delete assignment record"
                          >
                            <Trash className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
