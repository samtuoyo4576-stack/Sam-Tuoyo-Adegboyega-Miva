import { STUDENT_PROFILE } from '../data';
import { ArrowRight, GraduationCap, Compass, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import React from 'react';

export default function Homepage({ setActiveTab }) {
  return (
    <div className="space-y-12" id="homepage-container">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white rounded-3xl px-6 py-12 md:p-16 shadow-xl" id="hero-section">
        {/* Decorative Grid Overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-25"></div>
        
        <div className="relative max-w-5xl mx-auto flex flex-col md:flex-row items-center gap-10 md:gap-16">
          {/* Photograph Container */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="relative flex-shrink-0"
            id="student-photo-wrapper"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-blue-500 to-indigo-500 rounded-2xl blur-lg opacity-30 transform rotate-6"></div>
            <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-2xl overflow-hidden border-4 border-white/10 shadow-2xl">
              <img
                src={STUDENT_PROFILE.avatar}
                alt={STUDENT_PROFILE.name}
                className="w-full h-full object-cover object-top transform hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
                id="student-photo"
              />
            </div>
            {/* Overlay badge */}
            <div className="absolute -bottom-3 -right-3 bg-blue-600 text-white px-4 py-1.5 rounded-full text-xs font-semibold shadow-lg border border-white/10 flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5" />
              <span>{STUDENT_PROFILE.university}</span>
            </div>
          </motion.div>

          {/* Hero Content */}
          <div className="flex-1 text-center md:text-left space-y-5" id="hero-text-content">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-medium text-blue-200 border border-white/5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Current Term: Academic Year 2026</span>
            </div>

            <div className="space-y-2">
              <h1 className="font-display text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight" id="student-name">
                Hi, I'm <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-teal-200 bg-clip-text text-transparent">{STUDENT_PROFILE.name}</span>
              </h1>
              <p className="font-display text-lg sm:text-xl text-slate-300 font-medium" id="student-title">
                {STUDENT_PROFILE.title}
              </p>
            </div>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl font-light" id="welcome-message">
              "{STUDENT_PROFILE.welcomeMessage}"
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 pt-3">
              <button
                onClick={() => setActiveTab('planner')}
                className="bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-medium px-6 py-3 rounded-xl transition-all duration-200 flex items-center gap-2 shadow-lg shadow-blue-600/20 text-sm group"
                id="hero-planner-cta"
              >
                Go to Study Planner
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
              <button
                onClick={() => setActiveTab('about')}
                className="bg-white/10 hover:bg-white/15 active:bg-white/5 border border-white/10 text-white font-medium px-6 py-3 rounded-xl transition-all duration-200 text-sm"
                id="hero-about-cta"
              >
                Learn More About Me
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Biography and Focus Sections */}
      <section className="max-w-5xl mx-auto" id="bio-section">
        {/* Biography */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
              <Compass className="w-5.5 h-5.5" />
            </div>
            <div>
              <h2 className="font-display font-bold text-xl text-slate-900">Personal Biography</h2>
              <p className="text-slate-400 text-xs font-mono">ABOUT SAM TUOYO</p>
            </div>
          </div>

          <p className="text-slate-600 text-sm sm:text-base leading-relaxed font-normal">
            {STUDENT_PROFILE.bioSummary}
          </p>

          <div className="space-y-3.5 bg-slate-50/70 p-5 rounded-2xl border border-slate-100">
            <h3 className="font-display font-semibold text-sm text-slate-800">Core Academic Philosophies</h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-slate-600" id="academic-philosophy-list">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2"></span>
                <span>Active project-based application of academic principles</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2"></span>
                <span>Structured self-paced learning and time management</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2"></span>
                <span>Writing readable, clean, and accessible codebases</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2"></span>
                <span>Collaboration and mentorship within study peer circles</span>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
}
