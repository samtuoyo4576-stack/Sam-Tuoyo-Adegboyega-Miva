import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { STUDENT_PROFILE } from '../data';

export default function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('Academic Peer Inquiry');
  const [message, setMessage] = useState('');

  // Validation States
  const [errors, setErrors] = useState({});
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // Strict Phone and Email check
  const validateForm = () => {
    const newErrors = {};

    // 1. No field is empty
    if (!name.trim()) {
      newErrors.name = 'Name field is required.';
    }
    if (!email.trim()) {
      newErrors.email = 'Email address is required.';
    }
    if (!phone.trim()) {
      newErrors.phone = 'Phone number is required.';
    }
    if (!message.trim()) {
      newErrors.message = 'Message field is required.';
    }

    // 2. Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email.trim() && !emailRegex.test(email.trim())) {
      newErrors.email = 'Please provide a valid email format (e.g. user@domain.com).';
    }

    // 3. Phone number contains only digits
    const digitsOnlyRegex = /^\d+$/;
    if (phone.trim() && !digitsOnlyRegex.test(phone.trim())) {
      newErrors.phone = 'Phone number must contain only digits (no spaces, dashes, or special characters).';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      // Form is fully valid
      setShowSuccessModal(true);
      // Reset form fields
      setName('');
      setEmail('');
      setPhone('');
      setMessage('');
      setSubject('Academic Peer Inquiry');
      setErrors({});
    }
  };

  return (
    <div className="space-y-12" id="contact-container">
      {/* Intro Header */}
      <section className="text-center max-w-3xl mx-auto space-y-4" id="contact-header">
        <h2 className="font-display font-black text-3xl sm:text-4xl text-slate-900 tracking-tight">
          Get In Touch
        </h2>
        <p className="text-slate-500 text-sm sm:text-base leading-relaxed">
          Have an academic project in mind, a peer collaboration query, or general questions? Drop a message using the verified form below.
        </p>
      </section>

      {/* Main Grid: Info on left, Form on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="contact-grid-layout">
        
        {/* Contact Info (5 Cols) */}
        <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-8" id="contact-details-panel">
          <div className="space-y-2">
            <h3 className="font-display font-bold text-xl text-slate-900">{STUDENT_PROFILE.name}</h3>
            <p className="text-sm text-slate-500 font-medium">{STUDENT_PROFILE.title}</p>
            <p className="text-xs text-slate-400 font-mono">MIVA Open University</p>
          </div>

          <div className="space-y-5" id="contact-cards-list">
            <div className="flex gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center shrink-0">
                <Mail className="w-5 h-5" />
              </div>
              <div className="space-y-0.5">
                <p className="text-xxs font-bold text-slate-400 uppercase tracking-wider font-mono">Student Email</p>
                <a href={`mailto:${STUDENT_PROFILE.email}`} className="text-sm font-semibold text-slate-700 hover:text-blue-600 transition-colors">
                  {STUDENT_PROFILE.email}
                </a>
              </div>
            </div>

            <div className="flex gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div className="space-y-0.5">
                <p className="text-xxs font-bold text-slate-400 uppercase tracking-wider font-mono">Mobile Contact</p>
                <a href={`tel:${STUDENT_PROFILE.phone}`} className="text-sm font-semibold text-slate-700 hover:text-indigo-600 transition-colors">
                  {STUDENT_PROFILE.phone}
                </a>
              </div>
            </div>

            <div className="flex gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="w-10 h-10 bg-teal-50 text-teal-600 rounded-xl flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div className="space-y-0.5">
                <p className="text-xxs font-bold text-slate-400 uppercase tracking-wider font-mono">Academic Campus</p>
                <p className="text-sm font-semibold text-slate-700">
                  MIVA Open University, Abuja Headquarters, Nigeria
                </p>
              </div>
            </div>
          </div>

          <div className="p-5 bg-blue-50/50 border border-blue-100/50 rounded-2xl flex gap-3.5 items-start">
            <Clock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-blue-900 uppercase tracking-wide">Inquiry Response Window</h4>
              <p className="text-xs text-blue-700 leading-relaxed font-light">
                I aim to respond to peer collaborative proposals, educational suggestions, and assignments within 24 to 48 hours.
              </p>
            </div>
          </div>
        </div>

        {/* Form on Right (7 Cols) */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm" id="contact-form-card">
          <form onSubmit={handleSubmit} className="space-y-5" id="academic-contact-form" noValidate>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Name */}
              <div className="space-y-1.5">
                <label htmlFor="form-name" className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  id="form-name"
                  placeholder="e.g. Jane Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={`w-full bg-slate-50 border focus:bg-white rounded-xl px-4 py-3 text-sm transition-all focus:outline-none ${
                    errors.name ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-blue-500'
                  }`}
                />
                {errors.name && (
                  <p className="text-xxs font-bold text-rose-600 flex items-center gap-1" id="err-name">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.name}</span>
                  </p>
                )}
              </div>

              {/* Email */}
              <div className="space-y-1.5">
                <label htmlFor="form-email" className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Email Address *
                </label>
                <input
                  type="email"
                  id="form-email"
                  placeholder="e.g. janedoe@miva.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full bg-slate-50 border focus:bg-white rounded-xl px-4 py-3 text-sm transition-all focus:outline-none ${
                    errors.email ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-blue-500'
                  }`}
                />
                {errors.email && (
                  <p className="text-xxs font-bold text-rose-600 flex items-center gap-1" id="err-email">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.email}</span>
                  </p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Phone */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label htmlFor="form-phone" className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                    Phone Number *
                  </label>
                  <span className="text-slate-400 text-[10px] font-mono">Digits only</span>
                </div>
                <input
                  type="text"
                  id="form-phone"
                  placeholder="e.g. 08123456789"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className={`w-full bg-slate-50 border focus:bg-white rounded-xl px-4 py-3 text-sm transition-all focus:outline-none ${
                    errors.phone ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-blue-500'
                  }`}
                />
                {errors.phone && (
                  <p className="text-xxs font-bold text-rose-600 flex items-center gap-1" id="err-phone">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.phone}</span>
                  </p>
                )}
              </div>

              {/* Subject */}
              <div className="space-y-1.5">
                <label htmlFor="form-subject" className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Subject Category
                </label>
                <select
                  id="form-subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl px-3 py-3 text-sm transition-all focus:outline-none cursor-pointer"
                >
                  <option value="Academic Peer Inquiry">Academic Peer Inquiry</option>
                  <option value="Project Collaboration">Project Collaboration</option>
                  <option value="Technical Mentorship">Technical Mentorship</option>
                  <option value="General Feedback">General Feedback</option>
                </select>
              </div>
            </div>

            {/* Message */}
            <div className="space-y-1.5">
              <label htmlFor="form-message" className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                Detailed Message *
              </label>
              <textarea
                id="form-message"
                placeholder="Write your academic inquiry details or peer questions here..."
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className={`w-full bg-slate-50 border focus:bg-white rounded-xl px-4 py-3 text-sm transition-all focus:outline-none resize-none ${
                  errors.message ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-blue-500'
                }`}
              ></textarea>
              {errors.message && (
                <p className="text-xxs font-bold text-rose-600 flex items-center gap-1" id="err-message">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{errors.message}</span>
                </p>
              )}
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg shadow-blue-600/10 transition-all text-sm flex items-center justify-center gap-2 cursor-pointer"
              id="contact-submit-btn"
            >
              <Send className="w-4 h-4" />
              <span>Send Message</span>
            </button>
          </form>
        </div>

      </div>

      {/* Success Modal Overlay */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-55 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in" id="success-modal-overlay">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full border border-slate-100 shadow-2xl space-y-6 text-center transform scale-100 transition-transform">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <h3 className="font-display font-bold text-xl text-slate-900">Message Transmitted!</h3>
              <p className="text-slate-500 text-sm leading-relaxed">
                Thank you for reaching out. The JavaScript validation layer confirmed correct formats, and your form submission was simulated successfully.
              </p>
            </div>

            <button
              onClick={() => setShowSuccessModal(false)}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-3 rounded-xl transition-colors text-sm cursor-pointer"
              id="success-modal-close"
            >
              Close Confirmation
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
