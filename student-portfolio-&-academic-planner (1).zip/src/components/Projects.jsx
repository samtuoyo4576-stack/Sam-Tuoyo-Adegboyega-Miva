import { useState } from 'react';
import { INITIAL_PROJECTS } from '../data';
import { ExternalLink, Github, Sparkles, Filter, Code, CheckCircle, X } from 'lucide-react';
import { motion } from 'motion/react';

export default function Projects() {
  const [filter, setFilter] = useState('All');
  const [activeProjectDemo, setActiveProjectDemo] = useState(null);
  
  const categories = ['All', ...Array.from(new Set(INITIAL_PROJECTS.map(p => p.category)))];

  const filteredProjects = filter === 'All' 
    ? INITIAL_PROJECTS 
    : INITIAL_PROJECTS.filter(p => p.category === filter);

  return (
    <div className="space-y-12" id="projects-container">
      {/* Intro Header */}
      <section className="text-center max-w-3xl mx-auto space-y-4" id="projects-header">
        <h2 className="font-display font-black text-3xl sm:text-4xl text-slate-900 tracking-tight">
          Featured Engineering Projects
        </h2>
        <p className="text-slate-500 text-sm sm:text-base leading-relaxed">
          Explore a curated selection of systems, software prototypes, and dashboards designed to address educational workflow demands and information visualizers.
        </p>
      </section>

      {/* Filter Chips Bar */}
      <div className="flex flex-wrap items-center justify-center gap-2" id="projects-filter-bar">
        <div className="flex items-center gap-1.5 text-slate-400 text-xs font-mono uppercase font-semibold mr-2">
          <Filter className="w-3.5 h-3.5" />
          <span>Filter:</span>
        </div>
        {categories.map((cat, idx) => (
          <button
            key={idx}
            id={`filter-btn-${cat.toLowerCase().replace(/\s+/g, '-')}`}
            onClick={() => setFilter(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-medium font-display transition-all ${
              filter === cat
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/15'
                : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200/60'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Projects Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="projects-grid">
        {filteredProjects.map((project, idx) => (
          <div
            key={project.id}
            id={`project-card-${project.id}`}
            className="group bg-white rounded-3xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col h-full"
          >
            {/* Project Image Frame */}
            <div className="relative aspect-4/3 overflow-hidden bg-slate-900" id={`project-image-wrapper-${project.id}`}>
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              {/* Overlay Badge */}
              <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-md text-slate-800 px-3 py-1 rounded-lg text-xxs font-mono uppercase tracking-wider font-bold shadow-md border border-slate-100">
                {project.category}
              </div>
            </div>

            {/* Project Content */}
            <div className="p-6 flex-1 flex flex-col justify-between space-y-4" id={`project-content-${project.id}`}>
              <div className="space-y-2.5">
                <h3 className="font-display font-bold text-lg text-slate-900 group-hover:text-blue-600 transition-colors">
                  {project.title}
                </h3>
                <p className="text-slate-500 text-xs sm:text-sm leading-relaxed font-light">
                  {project.description}
                </p>
              </div>

              <div className="space-y-4 pt-2">
                {/* Tech Tags */}
                <div className="flex flex-wrap gap-1.5" id={`project-tags-${project.id}`}>
                  {project.tags.map((tag, tagIdx) => (
                    <span
                      key={tagIdx}
                      className="inline-flex items-center gap-1 text-xxs font-medium bg-slate-50 text-slate-500 px-2 py-0.5 rounded-md border border-slate-100"
                    >
                      <Code className="w-2.5 h-2.5 text-slate-400" />
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Hyperlinks (Simulated / Real) */}
                <div className="flex items-center justify-between border-t border-slate-50 pt-4" id={`project-links-${project.id}`}>
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors"
                  >
                    <Github className="w-4 h-4" />
                    <span>View Repository</span>
                  </a>

                  <a
                    href={project.demoUrl}
                    onClick={(e) => {
                      if (project.demoUrl === '#') {
                        e.preventDefault();
                        setActiveProjectDemo(project.title);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-700 transition-colors"
                  >
                    <span>Live Preview</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Live Demo Simulation Modal */}
      {activeProjectDemo && (
        <div className="fixed inset-0 z-55 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in" id="demo-modal-overlay">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full border border-slate-100 shadow-2xl space-y-6 text-center transform scale-100 transition-transform">
            <div className="w-16 h-16 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <Sparkles className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h3 className="font-display font-bold text-xl text-slate-900">Simulation Activated</h3>
              <p className="text-slate-400 text-xs font-mono uppercase tracking-wider">PROJECT: {activeProjectDemo}</p>
              <p className="text-slate-500 text-sm leading-relaxed">
                Opening Live Demo Simulation for <strong>"{activeProjectDemo}"</strong>! This modal represents a simulated staging deployment of this web engineering release.
              </p>
            </div>

            <button
              onClick={() => setActiveProjectDemo(null)}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-3 rounded-xl transition-colors text-sm cursor-pointer"
              id="demo-modal-close"
            >
              Dismiss Simulation
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
