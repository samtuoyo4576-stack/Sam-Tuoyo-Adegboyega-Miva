import React from 'react';
import { EDUCATION_TIMELINE, TECHNICAL_SKILLS, HOBBIES, STUDENT_PROFILE } from '../data';
import { Calendar, Award, GraduationCap, Briefcase, Sparkles, BookOpen, Palette, Cpu, Dices } from 'lucide-react';
import { motion } from 'motion/react';

// Dynamic Icon Map for Hobbies
const HOBBY_ICONS = {
  BookOpen: BookOpen,
  Palette: Palette,
  Cpu: Cpu,
  Dices: Dices
};

export default function AboutMe() {
  return (
    <div className="space-y-12" id="about-me-container">
      {/* Intro Header */}
      <section className="text-center max-w-3xl mx-auto space-y-4" id="about-header">
        <h2 className="font-display font-black text-3xl sm:text-4xl text-slate-900 tracking-tight">
          About Me
        </h2>
        <p className="text-slate-500 text-sm sm:text-base leading-relaxed">
          Dedicated Frontend Developer with a strong focus on HTML, CSS, and JavaScript. Specializing in creating semantic markup, clean styling with Tailwind CSS, and highly interactive user interfaces.
        </p>
      </section>

      {/* Grid: Education Timeline & Career Aspirations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="about-grid">
        {/* Educational Timeline & Honors (7 Cols) */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-8" id="education-section">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
              <GraduationCap className="w-5.5 h-5.5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900">Academic Background & Awards</h3>
              <p className="text-slate-400 text-xs font-mono">EDUCATIONAL HISTORY</p>
            </div>
          </div>

          <div className="relative border-l-2 border-blue-100 pl-6 ml-3 space-y-8" id="timeline-flow">
            {EDUCATION_TIMELINE.map((item) => {
              const isAward = item.type === 'award';
              return (
                <div key={item.id} className="relative group" id={`timeline-item-${item.id}`}>
                  {/* Outer circle badge */}
                  <span className={`absolute -left-[31px] top-1.5 w-4.5 h-4.5 rounded-full border-4 border-white shadow-sm flex items-center justify-center transition-colors ${
                    isAward ? 'bg-amber-500 ring-2 ring-amber-100' : 'bg-blue-600 ring-2 ring-blue-100'
                  }`}>
                  </span>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs font-semibold text-slate-400 bg-slate-100 px-2.5 py-0.5 rounded-full">
                        {item.period}
                      </span>
                      {isAward && (
                        <span className="inline-flex items-center gap-1 text-xxs font-semibold bg-amber-50 text-amber-700 px-2.5 py-0.5 rounded-full border border-amber-100">
                          <Award className="w-3 h-3 text-amber-500 fill-amber-500" />
                          Academic Honor
                        </span>
                      )}
                    </div>
                    
                    <h4 className="font-display font-bold text-base text-slate-900 group-hover:text-blue-600 transition-colors">
                      {item.title}
                    </h4>
                    
                    <p className="text-xs font-semibold text-slate-500">
                      {item.institution}
                    </p>
                    
                    <p className="text-slate-600 text-sm leading-relaxed pt-1">
                      {item.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Career Aspirations (5 Cols) */}
        <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6" id="aspirations-section">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600">
              <Briefcase className="w-5.5 h-5.5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900">Career Aspirations</h3>
              <p className="text-slate-400 text-xs font-mono">FUTURE GOALS & OBJECTIVES</p>
            </div>
          </div>

          <div className="space-y-4" id="aspirations-list">
            {STUDENT_PROFILE.careerAspirations.map((asp, idx) => (
              <div 
                key={idx} 
                className="p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100/50 border border-slate-100 hover:border-blue-100 hover:bg-white hover:shadow-md transition-all duration-300 group"
                id={`aspiration-card-${idx}`}
              >
                <div className="flex gap-3">
                  <div className="w-7 h-7 bg-white rounded-lg flex items-center justify-center text-blue-600 border border-slate-200 group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300 font-bold font-mono text-xs">
                    0{idx + 1}
                  </div>
                  <div className="flex-1 space-y-1">
                    <h4 className="font-display font-bold text-sm text-slate-900 group-hover:text-blue-600 transition-colors">
                      {asp.title}
                    </h4>
                    <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
                      {asp.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Core Vision Statement */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-5 rounded-2xl text-white space-y-2">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-blue-200" />
              <span className="font-mono text-xxs tracking-wider uppercase font-bold text-blue-200">Personal Commitment</span>
            </div>
            <p className="text-xs sm:text-sm leading-relaxed font-light">
              "To write pristine, standards-compliant HTML, CSS, and modern JavaScript, crafting accessible and lightning-fast user experiences on the web."
            </p>
          </div>
        </div>
      </div>

      {/* Grid: Technical Skills & Hobbies */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="skills-hobbies-wrapper">
        {/* Technical Skills Meter (5 Cols) */}
        <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6" id="skills-section">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600">
              <Cpu className="w-5.5 h-5.5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900">Technical Skills</h3>
              <p className="text-slate-400 text-xs font-mono">COMPETENCY METERS</p>
            </div>
          </div>

          <div className="space-y-4.5" id="skills-list">
            {TECHNICAL_SKILLS.map((skill, idx) => (
              <div key={idx} className="space-y-1.5" id={`skill-item-${idx}`}>
                <div className="flex justify-between items-center text-xs sm:text-sm">
                  <span className="font-semibold text-slate-700">{skill.name}</span>
                  <span className="font-mono text-xs text-slate-400 font-medium bg-slate-50 px-2 py-0.5 rounded-md">
                    {skill.level}%
                  </span>
                </div>
                {/* Level Bar Background */}
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-600 to-emerald-500 rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${skill.level}%` }}
                    id={`skill-bar-${idx}`}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Hobbies and Interests Card Grid (7 Cols) */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6" id="hobbies-section">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600">
              <Palette className="w-5.5 h-5.5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900">Hobbies & Interests</h3>
              <p className="text-slate-400 text-xs font-mono">PERSONAL PASSIONS</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" id="hobbies-grid">
            {HOBBIES.map((hobby, idx) => {
              const HobbyIcon = HOBBY_ICONS[hobby.iconName] || Palette;
              return (
                <div 
                  key={idx} 
                  className="p-5 rounded-2xl bg-amber-50/25 hover:bg-amber-50/50 border border-amber-100/50 hover:border-amber-200 transition-all duration-300 flex flex-col gap-3"
                  id={`hobby-card-${idx}`}
                >
                  <div className="w-9 h-9 bg-white rounded-xl flex items-center justify-center text-amber-600 shadow-sm border border-amber-100">
                    <HobbyIcon className="w-4.5 h-4.5" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-display font-bold text-sm text-slate-900">
                      {hobby.name}
                    </h4>
                    <p className="text-slate-500 text-xs sm:text-sm leading-relaxed font-light">
                      {hobby.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
