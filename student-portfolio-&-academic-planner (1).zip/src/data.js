export const STUDENT_PROFILE = {
  name: 'Sam Tuoyo Adegboyega',
  title: 'Computer Science Student & Mechatronics Enthusiast',
  university: 'MIVA Open University',
  studentId: 'MIVA-2025-4576',
  email: 's.adegboyega4576@miva.edu.ng',
  phone: '07067071430',
  avatar: 'https://lh3.googleusercontent.com/d/1EsDHA2NTPrf9R4CS1d610ueY7NTHM4wi',
  welcomeMessage: 'Welcome to my academic and professional portal! Dedicated to excellence in computer science, mechatronic systems engineering, and modern web application development.',
  bioSummary: 'I am a detail-oriented and technically skilled Computer Science student with a solid background in Mechatronics and Mechanical Engineering. I combine hardware-software systems logic, embedded control, and clean web technologies to design integrated solutions. Experienced in semantic coding, web interfaces, and diagnostic programming.',
  careerAspirations: [
    {
      title: 'Computer Scientist & Systems Engineer',
      description: 'Leveraging algorithmic foundations, data structures, and software principles to design efficient scalable applications and automate industrial processes.'
    },
    {
      title: 'Mechatronics & Automation Engineer',
      description: 'Designing and programming embedded systems, smart control loops, and electro-mechanical architectures combining hardware and software.'
    },
    {
      title: 'Full-Stack Developer & Technical Innovator',
      description: 'Bridging the gap between hardware controls and clean web/cloud interfaces to create modern web portals and monitoring dashboards.'
    }
  ]
};

export const EDUCATION_TIMELINE = [
  {
    id: 'edu-1',
    period: '2024 - Present',
    title: 'Bachelor of Science in Computer Science (Ongoing)',
    institution: 'MIVA Open University',
    description: 'Deepening academic knowledge in computer science, system architectures, database systems, mathematical foundations, and advanced software design.',
    type: 'education'
  },
  {
    id: 'edu-2',
    period: '2024 - 2025',
    title: 'Diploma in Mechatronics',
    institution: 'Institute for Industrial Technology (IIT)',
    description: 'Practical professional training in automation, electro-pneumatics, PLC programming, microcontrollers, sensor integration, and industrial control systems.',
    type: 'education'
  },
  {
    id: 'edu-3',
    period: '2020 - Present',
    title: 'Technical Projects Consultant & Web Developer',
    institution: 'CHI Limited & Freelance Portal',
    description: 'Implementing web automation, system monitoring dashboards, and robust web applications combining system parameters and interactive scripting.',
    type: 'experience'
  },
  {
    id: 'edu-4',
    period: '2020 - 2023',
    title: 'National Diploma in Mechanical Engineering',
    institution: 'Lagos State University of Science and Technology (LASUSTECH)',
    description: 'Completed comprehensive coursework in thermodynamics, fluid mechanics, machine design, CAD/CAM, engineering mathematics, and workshop technology.',
    type: 'education'
  }
];

export const TECHNICAL_SKILLS = [
  { name: 'Computer Science & Algorithms', category: 'Computing Foundations', level: 90 },
  { name: 'Mechatronic Systems & PLCs', category: 'Automation & Hardware', level: 88 },
  { name: 'Embedded Systems (C++/Python)', category: 'Computing Foundations', level: 85 },
  { name: 'Mechanical Design (CAD/SolidWorks)', category: 'Automation & Hardware', level: 86 },
  { name: 'Vanilla JavaScript (ES6+)', category: 'Web Technologies', level: 88 },
  { name: 'HTML5 & CSS3 Layouts', category: 'Web Technologies', level: 92 },
  { name: 'Tailwind CSS Utility Design', category: 'Web Technologies', level: 90 },
  { name: 'Relational Databases (SQL)', category: 'Computing Foundations', level: 84 }
];

export const HOBBIES = [
  {
    name: 'IoT & Microcontroller Projects',
    iconName: 'Cpu',
    description: 'Building connected smart devices and coding Arduino/Raspberry Pi microcontrollers to interface with various physical sensors and actuators.'
  },
  {
    name: 'Technical Systems Writing',
    iconName: 'BookOpen',
    description: 'Documenting control flow logic, mechanical configurations, and programming guides to help peers grasp engineering concepts.'
  },
  {
    name: 'Algorithm Challenges',
    iconName: 'Dices',
    description: 'Solving complex computational puzzles to sharpen procedural thinking, algorithmic efficiency, and low-level debugging skills.'
  },
  {
    name: 'UI Design for Dashboards',
    iconName: 'Palette',
    description: 'Designing clean and intuitive web visual interfaces specifically styled for monitoring telemetry, sensors, and system status.'
  }
];

export const INITIAL_PROJECTS = [
  {
    id: 'proj-1',
    title: 'IoT Telemetry Dashboard',
    description: 'Designed a highly responsive dashboard interface utilizing modern web standards to display simulated temperature, pressure, and motor speed sensor streams.',
    category: 'Mechatronics',
    tags: ['HTML5', 'Tailwind CSS', 'Vanilla JS', 'Sensors'],
    image: '/src/assets/images/project_portfolio_1782837707167.jpg',
    demoUrl: '#',
    githubUrl: 'https://github.com/sam-tuoyo/telemetry-dashboard'
  },
  {
    id: 'proj-2',
    title: 'Algorithmic Problem Solver',
    description: 'Constructed an interactive workspace showing visual step-by-step executions of classic searching, sorting, and structural logic solutions.',
    category: 'Computer Science',
    tags: ['Algorithms', 'Data Structures', 'Visualization', 'JS'],
    image: '/src/assets/images/project_study_1782837690607.jpg',
    demoUrl: '#',
    githubUrl: 'https://github.com/sam-tuoyo/algorithm-visualizer'
  },
  {
    id: 'proj-3',
    title: 'Mechanical Linkage CAD Portal',
    description: 'Created a structural catalog layout presenting dynamic designs of mechanical joints and components, offering interactive specs.',
    category: 'Mechanical Engineering',
    tags: ['CAD Models', 'Mechanical Specs', 'CSS Grid', 'Tailwind'],
    image: '/src/assets/images/project_academic_1782837677318.jpg',
    demoUrl: '#',
    githubUrl: 'https://github.com/sam-tuoyo/cad-linkages'
  }
];

export const INITIAL_TASKS = [
  {
    id: 'task-1',
    title: 'Implement Binary Search Tree Traversals',
    course: 'CSC201 - Data Structures and Algorithms',
    dueDate: '2026-07-06',
    priority: 'High',
    completed: false,
    notes: 'Verify pre-order, in-order, and post-order logic in Python. Ensure handling of empty root cases.'
  },
  {
    id: 'task-2',
    title: 'Write PLC Automation Control Script',
    course: 'MEC202 - Industrial Automation & PLCs',
    dueDate: '2026-07-10',
    priority: 'High',
    completed: false,
    notes: 'Draft a ladder logic diagram for a simulated pneumatic cylinders sequence at IIT lab.'
  },
  {
    id: 'task-3',
    title: 'Optimize Thread Scheduling Simulation',
    course: 'CSC205 - Operating Systems Foundations',
    dueDate: '2026-07-14',
    priority: 'Medium',
    completed: true,
    notes: 'Analyze Round-Robin scheduling parameters and calculate average waiting time metrics.'
  },
  {
    id: 'task-4',
    title: 'Solve Fluid Flow & Pipe Friction Worksheet',
    course: 'MEG201 - Basic Fluid Mechanics & Thermodynamics',
    dueDate: '2026-07-20',
    priority: 'Low',
    completed: false,
    notes: 'Calculate Reynolds numbers and head losses across varied diameter pipe segments.'
  }
];
